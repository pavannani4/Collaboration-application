'use strict';

app.factory('AdminService', [ '$http', '$q', '$rootScope',
		function($http, $q, $rootScope) {
			console.log("AdminService...");

			var BASE_URL = 'http://localhost:8081/Binder'
			return {

			};
		} ]);