'use strict';

app.controller('AdminController', [
        '$scope', 
        'AdminService', 
        '$location',
		'$rootScope', 
		function($scope, AdminService, $location, $rootScope) {
        	console.log("AdminController...");
        	
        	var self = this;
        	
        	
		} ]);