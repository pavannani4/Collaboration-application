package com.niit.dao;

public interface MessageDAO {

}
