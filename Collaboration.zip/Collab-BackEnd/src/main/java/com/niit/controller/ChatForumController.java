package com.niit.controller;

/*import org.apache.log4j.Logger;

import com.niit.model.Message;
import com.niit.model.OutputMessage;

public class ChatForumController {
	
	private static final Logger Logger = Logger.getLogger("ChatForumController");
			
			
			public OutputMessage sendMessage(Message message){
		Logger.debug("Calling sendMessage method");
		Logger.debug("Message: ", message.getMessage());
		Logger.debug("Message ID: ");
	}
			

}*/
